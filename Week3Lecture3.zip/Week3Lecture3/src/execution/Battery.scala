package execution

class Battery(var charge: Int){

}
